	/*
 * sum.c
 *
 *  Created on: Jan 24, 2012
 *      Author: vignesh
 */

#include "sum.h"		
		
int sum(int a, int b) // defines the meaning
{
	return a+b+1000;

}
