/*
 * sum.h
 *
 *  Created on: Jan 24, 2012
 *      Author: vignesh
 */



int sum(int a, int b); // decleration
